
from socket import (
    socket, AF_INET, SOCK_STREAM,
    SOL_SOCKET, SO_REUSEADDR
)


def main():
    sock = socket(AF_INET, SOCK_STREAM)
    sock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    response=sock.connect_ex((
        '127.0.0.1',
        9000
    ))
    if response == 0:
        while True:
            message: str = None
            message = input("Enter your message::")
            sock.sendall(message.encode())

            if message == "EXIT":
                break
            del message

        sock.close()
        SystemExit, print("Exit system successfully")
    elif response == 111:
        print("Server is down plz try leter")
        sock.close()
        SystemExit, print("we have problem to connection")
    else:
        sock.close()
        SystemExit, print("we have problem to connection")
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Client cancel with user request...")

