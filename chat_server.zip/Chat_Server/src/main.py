
from modules.services.sockets.server_tcp import TCPServer

def main():
    TCPServer(
        "127.0.0.1",
        9000
    ).connect()

main()
