
from threading import Thread
from datetime import datetime

class ClientHandler(Thread):

    def __init__(self, client, client_address):
        Thread.__init__(self)

        self,client = client

    def run(self):
        message: str = None
        message = self.client.recv(8096).decode("utf-8")
        if message == None:
            del message
            self.run()
        elif message == "EXIT":
            del message
            self.daemon = True
            self.join()
        else:

            print("[" + str(datetime.now()) + "] => recive message from %s as: %s" % (
                self.client_address, message)
            )
            del message
            self.run()
