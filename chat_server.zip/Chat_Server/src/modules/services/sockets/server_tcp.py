
from socket import (
    socket, AF_INET, SOCK_STREAM, SOL_SOCKET, SO_REUSEADDR
)

from datetime import datetime

from .client_handler import ClientHandler

class TCPServer:
    def __init__(self, ip_address, dest_port):
        super(TCPServer, self).__init__()

        self.ip_address = ip_address
        self.dest_port = dest_port

        self.sock = socket(AF_INET, SOCK_STREAM)
        self.sock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)


    def connect(self):
        print("[+] Server started successfully...")
        self.sock.bind((self.ip_address, self.dest_port))
        self.sock.listen(10)
        self.__run__()

    def __run__(self):
        #while True:
        client, client_address = self.sock.accept()
        print(
            "[" + str(datetime.now()) + "] => We got new connection as %s " % (client_address))

        ClientHandler(client, client_address).start()
        self.__run__()

